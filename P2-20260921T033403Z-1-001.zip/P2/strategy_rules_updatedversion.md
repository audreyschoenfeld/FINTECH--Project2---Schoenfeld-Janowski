# strategy_rules.md — FINA 4075/5075 Project 2, Fall 2026

Pre-registration for Project 2, The Strategy Lab. Locked at the pre-registration commit (Sun 9/20); this file governs if the code and this file ever disagree.

## STRATEGY

Low volatility (36-month): buy the calmest stocks (Strategy Menu, Section 2, item (c)).

## UNIVERSE

The 200 stocks in P2_ticker_list_2026-08-31.csv, all of them, every month. No additions, no exclusions, no liquidity, price, market-cap or sector screens. If a panel company is acquired or delisted during the live window, the extension file carries its final partial-month return and a note; the name is treated as exited from the universe from the following month, and the exit is stated in that checkpoint's log entry (Data Dictionary, Section 4).

## DATA

panel_returns_2026-08-31.csv, 200 stocks x 92 months, wide layout (column 1 = month-end date, remaining 200 columns = tickers in company-list order, grouped by sector and largest market cap first — not alphabetical). Read with pd.read_csv(path, index_col=0, parse_dates=True). Row 0 = January 2019 (2019-01-31), row 91 = August 2026 (2026-08-31). Values are simple monthly total returns in decimal form (0.0234 = +2.34%), dividend- and split-adjusted, rounded to six decimals, with no missing values anywhere in the released table.

SHA-256 panel_returns_2026-08-31.csv = c9d3340eba3a3301a63bb788c87f1d6e9e55de58a3fec16b12a34b313cac076b; SHA-256 P2_ticker_list_2026-08-31.csv = ef2701991201187ddc5481d2c143be5ae41f2fcf7ad0027d21e3e5670ae5bf4c (both as published in the Data Dictionary, Section 1; checked with sha256sum after download). Plus the instructor's dated cumulative extension files for September, October and November 2026, each committed with its checkpoint entry and its own published hash. The posted files are authoritative; no rebuilt panel is used for any graded number. Nothing dated before 8/31/2026 changes at any checkpoint.

## SIGNAL

For the portfolio held during month t, the sample standard deviation (ddof=1) of the 36 monthly total returns for months t-36 through t-1 inclusive: vol_t = std(r_{t-36}, r_{t-35}, ..., r_{t-1}), ddof=1. No skip-month — the most recent month (t-1) IS used, unlike the momentum menu items. In code the window is rets[t-36] (Python slicing stops before t, so the slice holds rows t-36 .. t-1). Lower volatility is better. This ranks on total volatility, the raw standard deviation of monthly returns — not beta and not idiosyncratic or residual volatility, which are separate Section 4 strategies. Sample standard deviation (ddof=1) is used rather than population; this does not change the ranking but does change the reported numbers, so it is fixed here. Extreme months in the panel (for example the March and April 2020 energy moves, LUMN in July 2024, TDS and AD in August 2023) are genuine market history and enter the standard deviation as-is: no winsorizing, trimming or dropping.

## MISSING DATA

if any of the 36 monthly returns in a stock's window is missing (the stock was not yet listed, or has delisted), the stock is ineligible for that month and is not ranked. The released panel has no missing values; this rule governs the live window only.

## RANKING

Ascending by volatility (lowest first). TIE-BREAK: if two or more stocks tie at the 20th/21st rank boundary, fill the remaining slots with the alphabetically earliest tickers among the tied names (Python string order on the ticker symbol), up to exactly 20 holdings. This is alphabetical order on the ticker, NOT the panel's column order: the panel's columns are ordered by sector and market cap, so a bare np.argsort tie-break (which takes the lower column index) would not satisfy this rule. Ties must be broken on the ticker string explicitly in code.

## PORTFOLIO

The 20 lowest-volatility stocks of the 200-stock panel (the top decile), equal weights of 1/20 each, fully invested, long only. Weights are reset to 1/20 at every month-end rebalance.

## REBALANCE

Monthly, at each month-end, using data through the prior month-end only. The portfolio held during month t is chosen from returns of months t-36 through t-1. Signal computation and the rebalance trade are both assumed to happen at the month-end close; this is a simplification and is stated as such in the report. The first month with a complete 36-month window is January 2022 (row 36, using rows 0-35 = January 2019 through December 2021). The in-sample backtest runs January 2022 - August 2026, 56 months.

## COSTS

10 basis points per side. One-way turnover in month t = (number of names in month t's portfolio that were not held in month t-1) / 20. Monthly cost = 2 x 0.0010 x turnover. The first month of any run (January 2022 in the backtest) counts as a full purchase (turnover = 1). Despite there being no sale in the first month, the first month is intentionally charged 20 basis points (2 x 0.0010 x 1), and this convention will not be altered. Net monthly return = equal-weight mean of the 20 holdings' returns for month t, minus the monthly cost. Turnover counts name replacement only. Rebalancing the weights of continuing holdings back to 1/20 after they drift during the month is assumed costless; this is a stated simplification, fixed for both tracks and the placebo. Turnover is expected to be low here (roughly 100-150% one-way per year, a cost drag near 0.2-0.3% per year) because a 36-month standard deviation changes little from one month to the next.

## BENCHMARK

Equal-weighted average of the stocks active that month (all 200 until a name delists, the remaining active names thereafter), rebalanced monthly, no costs, computed over the same January 2022 - August 2026 window used for the in-sample backtest and over the same live months for the live window.

## LIVE WINDOW

September, October and November 2026, scored month by month at the three checkpoints (Sun 10/11, Sun 11/8, Sun 12/6). The September 2026 portfolio is selected from the released panel (window = rows 56-91 = September 2023 through August 2026) and recorded in monitoring_log.md entry 0 inside the pre-registration commit. Each later month's portfolio is selected from the extended panel the day that extension file posts and recorded in that checkpoint's entry before the month it is scored on. Checkpoint 3 scores November and records no new holdings.

## PLACEBO PLAN (pre-registered)

1,000 random portfolios. Each draws 20 distinct tickers without replacement from the stocks active at the start of the live window (numpy default_rng, seed ____ — fill in and lock the value before committing), then buys and holds them across the live months with the same cost formula (first month = full purchase; a holding that delists is dropped and its weight redistributed equally among the survivors, matching the active-universe rule). For each track, report the gap versus the benchmark and its percentile in the placebo distribution of gaps. Percentile = 100 x (# placebo gaps <= strategy gap) / 1000.

## REPORTING

All statistics follow Section 3 of the Detailed Student Instructions: CAGR, annualized volatility (sample standard deviation x sqrt 12), Sharpe with rf = 0, maximum drawdown of the growth path, annual one-way turnover (mean monthly turnover x 12), and growth of $10,000. The report states the 56-month in-sample size explicitly and notes that it is not directly comparable to a 12-month-signal strategy backtested over 80 months; CAGRs across different sample windows are not compared without saying so. The report also states the panel's survivorship and selection bias: only companies still listed in September 2026 appear, and the universe was screened on 2026 market caps, so the equal-weighted panel compounds at roughly 17% a year over the in-sample period and every in-sample backtest on it is flattered. The live window does not carry this bias, which is why the live window is the evidence.

## NO

leverage, shorting, cash or T-bill positions, discretionary overrides, parameter changes (window length, estimator, holding count, weights, cost rate, tie-break), or edits to this file after the pre-registration commit. Any such change carries deduction code P0.
