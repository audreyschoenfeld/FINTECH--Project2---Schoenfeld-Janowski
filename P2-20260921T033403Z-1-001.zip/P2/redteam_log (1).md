# redteam_log.md — Group ____

Red-team of strategy_rules.md before the pre-registration commit (Project 2, Step 6).
Second AI: ____ (vendor, model and version exactly as shown in its UI), ____ (site or app), ____/2026.
Route: pasted the full rules file with the instruction "____" [paste the exact instruction you gave].
The reply raised 25 points. Related points are grouped here by the rule they touch, giving 12
findings. Eleven were real gaps and were fixed. One (finding 9) was already covered by Section 3 of the
Detailed Student Instructions and was fixed anyway so the file stands on its own. For finding 3 we
used the course's formula rather than the one the AI proposed. The full exchange (prompt and verbatim
reply) is in the AI Audit Note.

FINDING 1 — The placebo seed was blank, and the seed alone did not fix the draws.
  Quote: "numpy default_rng, seed ____ — fill in and lock the value before committing"
  Exploit: a researcher could try many seeds and keep the one whose placebo distribution makes the
  strategy look strongest. Even with a seed, the draws also depend on the order of the population,
  the exact sampling call and the numpy version, so the same seed could produce different portfolios.
  FIX: rewrote PLACEBO PLAN — "rng = numpy.random.default_rng(____), seed locked here before the
  commit." The population is taken in panel column order, and the 1,000 portfolios are drawn one after
  another, each with rng.choice(population, size=20, replace=False). The code runs in the pinned Colab
  runtime 2026.07 with the numpy version printed by the environment stamp, and the 1,000 sampled ticker
  sets are saved and committed. "Placebo seed" was added to the NO list of parameters that cannot change.

FINDING 2 — "Gap versus the benchmark" was not defined.
  Quote: "For each track, report the gap versus the benchmark and its percentile in the placebo
  distribution of gaps."
  Exploit: the gap could be a cumulative-return difference, a CAGR difference, a growth-of-$10,000
  difference or an average monthly excess return. A researcher could compute several and report the
  best one. The file also did not define "each track" or say whether net or gross returns were compared.
  FIX: added LIVE-WINDOW GAP — "gap = cumulative net return of the track over the live months minus the
  cumulative return of the benchmark over the same months, in percentage points ... No other gap
  measure ... is used to judge either track." STRATEGY now defines Track 1 and Track 2. BENCHMARK now
  says "Every comparison against the benchmark uses each track's returns net of its costs against the
  costless benchmark."

FINDING 3 — The percentile convention was not stated.
  Quote: "its percentile in the placebo distribution of gaps"
  Exploit: "strictly below" and "at or below" give different percentiles. With 1,000 draws the choice
  can move the reported number, and a researcher could pick the one that helps.
  FIX: added to PLACEBO PLAN — "percentile = 100 x (number of the 1,000 placebo gaps strictly below the
  track's gap) / 1,000, which is (gaps < my_gap).mean() x 100 as written in Section 3." The second AI
  suggested "<=". We used the strict "<" because Section 3 of the Detailed Student Instructions uses it,
  and the report is graded against that section.

FINDING 4 — The placebo's holding, return and delisting mechanics were open.
  Quote: "draws 20 distinct tickers without replacement from the stocks active at the start of the
  live window ... then buys and holds them ... a holding that delists is dropped and its weight
  redistributed equally among the survivors"
  Exploit: "buys and holds" suggests weights drift, but "redistributed equally" implies trading. The
  file did not give the monthly return formula, say whether a dropped name is refilled, say whether
  dropping or redistributing costs anything, or define exactly which stocks were "active at the start".
  Each of these choices changes the null distribution, and none was fixed in advance.
  FIX: rewrote PLACEBO PLAN. Population = "every ticker with an August 2026 return in the released panel
  (all 200)". Each portfolio "holds the same 20 names for all three live months and never adds a name".
  Monthly return = "the equal-weight mean of the returns of its holdings active that month", the same
  convention as Track 1, with reweighting assumed costless. The first month is charged 20 bp and later
  months have turnover 0. A delisted holding is not refilled, and dropping it carries no cost.

FINDING 5 — The first-month cost could be argued either way.
  Quote: "The first month of any run (January 2022 in the backtest) counts as a full purchase
  (turnover = 1)."
  Exploit: "10 basis points per side" could be read as 10 bp in the first month, since nothing is sold,
  but the formula charges 2 x 0.0010 x 1 = 20 bp. A researcher could invoke whichever reading helped.
  FIX: added to COSTS — the first month "is charged 2 x 0.0010 x 1 = 20 bp. This first-month charge is
  on purpose, even though no sale takes place in that month. It follows the course's run_track
  convention (Detailed Student Instructions, Section 5) and will not be changed." September 2026 is now
  named as the first month of the live window.

FINDING 6 — The file did not say whether a delisted holding counts toward Track 1's turnover.
  Quote: "One-way turnover in month t = (number of names in month t's portfolio that were not held in
  month t-1) / 20."
  Exploit: it was unclear whether a forced exit is charged as a trade, charged twice, or not charged at
  all.
  FIX: added to COSTS — "When a holding delists, the name that fills its slot at the next rebalance
  counts as one replaced name under the formula above. That is the only cost of a delisting; the
  delisting itself carries no separate charge."

FINDING 7 — Partial-month returns and acquisition proceeds were not defined, for the strategy or the
benchmark.
  Quote: "the extension file carries its final partial-month return and a note; the name is treated as
  exited from the universe from the following month", together with the NO rule "cash or T-bill
  positions".
  Exploit: after a mid-month acquisition, the proceeds could be held at zero, reinvested in the other
  holdings, or ignored. The NO-cash rule could be argued either way. The same questions applied to the
  benchmark, which moves the hurdle both tracks are judged against.
  FIX: added DELISTINGS AND CORPORATE ACTIONS, which applies to Track 1, the benchmark and the placebo.
  The supplied final partial-month return is the stock's "entire return contribution for month t, at
  its normal weight". Proceeds are not reinvested for the rest of the month, and this "forced event is
  not a discretionary cash position under the NO rule". The stock leaves the universe from month t+1.
  BENCHMARK now points to this rule.

FINDING 8 — The file did not say which month-end close forms the portfolio.
  Quote: "Signal computation and the rebalance trade are both assumed to happen at the month-end close"
  Exploit: the file did not say which close. That leaves room to move the month a portfolio earns by
  one, which would be look-ahead in one direction and a lost month in the other.
  FIX: rewrote REBALANCE — "The portfolio for month t is formed at the close of the last trading day of
  month t-1 and earns month t's return. For example, the September 2026 portfolio is formed at the
  August 31, 2026 close and earns the September 2026 return."

FINDING 9 — The statistic formulas were only referenced, not written out (already covered).
  Quote: "All statistics follow Section 3 of the Detailed Student Instructions: CAGR, ..., Sharpe with
  rf = 0, maximum drawdown of the growth path"
  Exploit: the Sharpe ratio can be built from the arithmetic mean or from CAGR; CAGR can be annualized
  in more than one way over 56 months; and it was unclear whether the starting $10,000 counts as the
  first peak for drawdown.
  FIX: Section 3 already defines all three, so this was not a live gap. The formulas were written into
  REPORTING anyway: CAGR = (V_T / V_0)^(12/T) - 1; Sharpe (rf = 0) = CAGR / annualized volatility
  ("it does not use the arithmetic mean return"); maximum drawdown is taken over the path "including V_0, so the
  starting $10,000 counts as the first peak".

FINDING 10 — "Tie" was undefined, and rounding would decide it.
  Quote: "if two or more stocks tie at the 20th/21st rank boundary, fill the remaining slots with the
  alphabetically earliest tickers ... (Python string order on the ticker symbol)"
  Exploit: a tie could mean exact floating-point equality or equality after rounding, and rounding
  changes which names tie. Checked on this panel: ranking on volatility rounded to four decimals would
  create a tie at the 20th slot in 9 of the 57 selection months (January 2022 – September 2026). On
  unrounded values there are none. Ticker comparison could also be bent by case or punctuation.
  FIX: added to SIGNAL — "volatility is computed and ranked in full floating-point (float64) precision
  and is never rounded before ranking." Added to RANKING — "A tie means exact equality of the unrounded
  float64 volatility values ... Tickers are compared exactly as they appear in the panel's column
  headers, with no case conversion and no removal of punctuation." Added to REPORTING — "rounding
  happens only in displayed results."

FINDING 11 — The file did not say which version governs if an extension file is corrected.
  Quote: "The posted files are authoritative"
  Exploit: if the instructor posts a corrected extension file, a researcher could keep whichever
  version gave the better result.
  FIX: added to DATA — "the governing file for each month is the one whose SHA-256 matches the hash the
  instructor currently publishes for it ... The replacement, both hashes and any change in holdings or
  scores are recorded in the next monitoring_log.md entry. We never choose between versions ourselves."

FINDING 12 — The file did not require every statistic to be reported.
  Quote: "All statistics follow Section 3 ... CAGR, annualized volatility ..., Sharpe with rf = 0,
  maximum drawdown ..., annual one-way turnover ..., and growth of $10,000."
  Exploit: the list named the statistics but did not require all of them, so an unflattering one could
  be left out of the report.
  FIX: added to REPORTING — "All six statistics are reported for Track 1 and the benchmark, whether or
  not they favor the strategy."

Effect on the numbers: none of the twelve fixes changes the in-sample backtest or the September 2026
holdings. The released panel has no missing values and no delistings (every name has continuous
history through August 2026, Data Dictionary Section 3), so findings 6 and 7 are dormant until the
live window. No two stocks have exactly equal volatility at the 20th/21st boundary in any of the 57
selection months from January 2022 through September 2026 (checked on unrounded values; the smallest
gap is about 0.0005 percentage points of monthly volatility), so the tie-break never binds. Finding
10 still matters, because rounding to four decimals before ranking would have created ties in 9 of
those months. Findings 1 to 4 govern only placebo and live-window scoring, none of which has been run.
Findings 5, 8 and 9 put in writing conventions that already appear in the course's reference formulas
and code (Sections 3 and 5). The value of the red-team is that the live window, the placebo and any
future rerun are now unambiguous.
